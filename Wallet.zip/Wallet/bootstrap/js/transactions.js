/**
 * AlkeWallet - Lista de Movimientos

 */

$(document).ready(function () {

    // Función que lee los datos guardados y los pone en la lista
    function cargarHistorial() {
        const historial = JSON.parse(localStorage.getItem('historial')) || [];
        const contenedor = $('#lista-transacciones');

        contenedor.empty();

        // Si no hay nada, muestra un icono y un aviso de "lista vacía"
        if (historial.length === 0) {
            contenedor.append(`
                <div class="text-center mt-5 py-5 opacity-50 animate__animated animate__fadeIn">
                    <i class="bi bi-receipt display-1"></i>
                    <p class="mt-3">Aún no tienes movimientos registrados.</p>
                </div>
            `);
            return;
        }

        // Dibuja cada movimiento con animaciones (el más nuevo arriba)
        historial.reverse().forEach(t => {
            const esCarga = t.tipo.includes('Carga');
            const signo = esCarga ? '+' : '-';
            const colorMonto = esCarga ? 'text-success' : 'text-danger';
            const icono = esCarga ? 'bi-arrow-down-left' : 'bi-arrow-up-right';

            contenedor.append(`
                <div class="transaction-item mb-3 animate__animated animate__fadeInUp">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <div class="icon-box me-3">
                                <i class="bi ${icono} fs-4"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 fw-bold text-white">${t.tipo}</h6>
                                <small class="text-muted" style="font-size: 0.75rem;">${t.fecha}</small>
                            </div>
                        </div>
                        <div class="text-end">
                            <span class="fw-bold ${colorMonto} fs-5">
                                ${signo} $${t.monto.toLocaleString('es-CL')}
                            </span>
                        </div>
                    </div>
                </div>
            `);
        });
    }

    // --- BORRAR HISTORIAL ---

    // Pregunta si estás seguro mediante un cuadro de confirmación
    $('#btn-borrar-historial').on('click', function () {
        const modalElement = document.getElementById('modalBorrar');
        if (modalElement) {
            const modal = new bootstrap.Modal(modalElement);
            modal.show();
        }
    });

    // Si confirmas, limpia la memoria y vuelve a cargar la lista vacía
    $('#confirmar-borrado').on('click', function () {
        localStorage.setItem('historial', JSON.stringify([]));
        cargarHistorial();

        const modalElement = document.getElementById('modalBorrar');
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) {
            modalInstance.hide();
        }
    });

    // Lanza la función de carga apenas se abre la página
    cargarHistorial();
});