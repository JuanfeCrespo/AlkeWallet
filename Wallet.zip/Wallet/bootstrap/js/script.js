/**
 * AlkeWallet - Pantalla de Bienvenida y Login
 * Autor: Juanfe Crespo
 */

$(document).ready(function () {

    setTimeout(function () {
        $('#loading-screen').fadeOut(500, function () {
            $(this).remove(); 
        });
    }, 2500);

    const formulario = document.getElementById('form-login');

    if (formulario) {
        formulario.addEventListener('submit', function (event) {
            event.preventDefault();

            const boton = $(this).find('button');
            const textoOriginal = boton.html();
            const email = document.getElementById('email').value;
            const pass = document.getElementById('password').value;

            // Hace que el botón de entrar cambie a "cargando"
            boton.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span>');

            // Revisa si los datos son correctos
            setTimeout(() => {
                if (email === "user@alke.com" && pass === "1234") {
                    // Si está correcto, sigue al menú
                    window.location.href = "menu.html";
                } else {
                    // Si falló, muestra el aviso de error 
                    const toastElement = document.getElementById('toastError');
                    const toast = new bootstrap.Toast(toastElement);

                    $('#mensajeError').text("El correo o la contraseña no coinciden.");
                    toast.show();

                    // Vuelve a poner el botón normal para intentar de nuevo
                    boton.prop('disabled', false).html(textoOriginal);
                }
            }, 1000);
        });
    }
});