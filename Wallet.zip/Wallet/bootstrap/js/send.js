$(document).ready(function () {

    // Datos iniciales: Dinero disponible actual, y contactos guardados
    let saldoActual = parseFloat(localStorage.getItem('saldo')) || 10000000;
    let contactos = JSON.parse(localStorage.getItem('contactos')) || [
        { nombre: "Chayanne" },
        { nombre: "Michael Jackson" },
        { nombre: "Ozzy Osbourne" }
    ];

    // Esta función dibuja los botones de mis contactos en la lista
    function renderizarContactos() {
        const lista = $('#lista-contactos');
        lista.empty();
        contactos.forEach((c) => {
            lista.append(`
                <button type="button" class="list-group-item list-group-item-action item-contacto py-3">
                    <div class="d-flex align-items-center">
                        <div class="bg-primary bg-opacity-10 rounded-circle me-3 d-flex align-items-center justify-content-center" style="width: 35px; height: 35px;">
                            <i class="bi bi-person text-primary"></i>
                        </div>
                        <span class="text-white fw-bold" data-nombre="${c.nombre}">${c.nombre}</span>
                    </div>
                </button>
            `);
        });
    }
    renderizarContactos();

    // Cuando haces clic en un contacto, pone su nombre automáticamente en el cuadro
    $(document).on('click', '.item-contacto', function () {
        const nombre = $(this).find('span').data('nombre');
      
        $(this).blur(); 

        $('#nombre-receptor').val(nombre);
        
        // Cerramos el cuadro de contactos de forma segura
        const modalEl = document.getElementById('modalContactos');
        const modalInstance = bootstrap.Modal.getInstance(modalEl);
        if (modalInstance) {
            modalInstance.hide();
        }
    });

    // Para guardar un nuevo contacto en la memoria
    $('#btn-agregar-contacto').on('click', function () {
        const nombre = $('#nuevo-contacto-nombre').val().trim();
        if (nombre) {
            contactos.push({ nombre: nombre });
            localStorage.setItem('contactos', JSON.stringify(contactos));
            renderizarContactos();
            $('#nuevo-contacto-nombre').val('');
        }
    });

    // --- PROCESO DE ENVIO DE DINERO ---
    $('#form-enviar').on('submit', function (e) {
        e.preventDefault();
        const receptor = $('#nombre-receptor').val();
        const monto = parseFloat($('#monto-enviar').val());

        // Si excede el monto del saldo en cuenta, se envia un aviso
        if (monto > saldoActual) {
            mostrarToast("Saldo insuficiente", "bg-danger");
            return;
        }

        // Resta el dinero y guarda el nuevo saldo
        saldoActual -= monto;
        localStorage.setItem('saldo', saldoActual);

        // Guarda este movimiento en la lista de actividades
        let historial = JSON.parse(localStorage.getItem('historial')) || [];
        historial.unshift({
            tipo: `Envío a ${receptor}`,
            monto: monto,
            fecha: new Date().toLocaleString(),
            clase: 'text-danger',
            icono: 'bi-send'
        });
        localStorage.setItem('historial', JSON.stringify(historial));

        mostrarToast("¡Dinero enviado con éxito!", "bg-primary");

        // Después de 2 segundos te devuelve al menú principal
        setTimeout(() => {
            window.location.href = 'menu.html';
        }, 2000);
    });

   
    function mostrarToast(msg, color) {
        const toastEl = $('#liveToast');
        toastEl.removeClass('bg-primary bg-danger').addClass(color);
        $('#toast-mensaje').text(msg);
        new bootstrap.Toast(toastEl[0]).show();
    }
});

function renderizarContactos() {
        const lista = $('#lista-contactos');
        lista.empty();
        contactos.forEach((c) => {
            // Se agrega 'bg-transparent' y 'border-secondary' para combinar con el modo oscuro de la app.
            lista.append(`
                <button type="button" class="list-group-item list-group-item-action item-contacto py-3 bg-transparent border-secondary border-opacity-25">
                    <div class="d-flex align-items-center">
                        <div class="bg-primary bg-opacity-10 rounded-circle me-3 d-flex align-items-center justify-content-center" style="width: 35px; height: 35px;">
                            <i class="bi bi-person text-primary"></i>
                        </div>
                        <span class="text-white fw-bold" data-nombre="${c.nombre}">${c.nombre}</span>
                    </div>
                </button>
            `);
        });
    }