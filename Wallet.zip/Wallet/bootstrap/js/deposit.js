/**
 * AlkeWallet - Carga de Saldo

 */

$(document).ready(function () {
    $('#form-depositar').on('submit', function (e) {
        e.preventDefault();

        const monto = parseFloat($('#monto-deposito').val());
        let saldoActual = parseFloat(localStorage.getItem('saldo')) || 10000000;

        // Suma la nueva carga al saldo anterior
        saldoActual += monto;
        localStorage.setItem('saldo', saldoActual);

        // Guarda la carga en el historial de transacciones
        let historial = JSON.parse(localStorage.getItem('historial')) || [];
        historial.unshift({
            tipo: 'Carga de Saldo',
            monto: monto,
            fecha: new Date().toLocaleString(),
            clase: 'text-success',
            icono: 'bi-arrow-down-left-circle-fill'
        });
        localStorage.setItem('historial', JSON.stringify(historial));

        // Muestra el mensaje de carga exitosa
        const toastEl = $('#liveToast');
        toastEl.addClass('bg-success');
        $('#toast-mensaje').text('¡Carga exitosa! Tu nuevo saldo se está actualizando.');
        bootstrap.Toast.getOrCreateInstance(toastEl[0]).show();

        // Redirige al inicio para ver el saldo actualizado
        setTimeout(() => {
            window.location.href = 'menu.html';
        }, 2000);
    });
});