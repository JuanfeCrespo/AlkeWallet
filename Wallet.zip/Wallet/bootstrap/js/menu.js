/**
 * AlkeWallet - Menú

 */

$(document).ready(function () {

    // Busca si ya hay dinero guardado en la memoria del navegador
    let saldoGuardado = localStorage.getItem('saldo');
    let saldoActual;

    // Si es la primera vez que inicia sesión, se asigna un monto de 10 millones por defecto
    if (saldoGuardado === null) {
        saldoActual = 10000000;
        localStorage.setItem('saldo', saldoActual);
    } else {
        // Si cuenta con saldo diferente producto del uso, se conserva el saldo "real"
        saldoActual = parseFloat(saldoGuardado);
    }

    // Pone el número del dinero en pantalla con puntos y signos de peso
    $('#saldo-total').text('$' + saldoActual.toLocaleString('es-CL'));
});